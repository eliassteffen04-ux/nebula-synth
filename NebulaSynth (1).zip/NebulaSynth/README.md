# Nebula Synth

Ein eigenständiger Layer-Synthesizer als VST3-Plugin (für FL Studio und jede andere DAW mit VST3).
Konzeptionell inspiriert von grossen Layer-Synths, aber komplett eigener Code, eigene Sounds, eigene Oberfläche.

## Funktionen

- **2 Sound-Layer (A + B)**, einzeln an-/abschaltbar
  - Wellenformen: Sine, Saw, Square, Triangle, Noise (Saw/Square bandbegrenzt mit PolyBLEP)
  - Unison mit bis zu 7 Stimmen, Detune und Stereo-Breite
  - Oktave, Feinstimmung, Pegel, Pan
  - Multimode-Filter (Lowpass, Bandpass, Highpass) mit Resonanz und Hüllkurven-Modulation
  - Eigene ADSR-Hüllkurve für Lautstärke und Filter
- **LFO** mit wählbarem Ziel: Cutoff, Pitch (Vibrato), Volume (Tremolo), Pan
- **Effekte:** Chorus, Stereo-Delay (Ping-Pong-Feedback), Reverb
- **Stimmen-Modi:**
  - *Poly*: mehrstimmig, Anzahl Stimmen 1–32 einstellbar (bei Überschreitung wird die älteste Stimme übernommen)
  - *Mono*: einstimmig, jede Note startet die Hüllkurven neu, Glide zwischen allen Noten
  - *Legato*: einstimmig, überlappend gespielte Noten gleiten ohne Neuanschlag
  - *Glide*-Regler (0–2 s) für die Gleitzeit in Mono und Legato
  - Beim Loslassen springt Mono/Legato zur zuletzt noch gehaltenen Note zurück
- Pitch-Bend ±2 Halbtöne, Velocity
- 56 Presets, im Menü nach Kategorien sortiert:
  - **Bass (7):** Sub Deep, Reese, Acid Squelch, Pluck Bass, Wobble, Fat Analog, Growl
  - **Keys (6):** Electric Piano, Soft Rhodes, Drawbar Organ, Digital Bell Keys, Wurly Grit, Dreamy Keys
  - **Plucks (7):** Glass Pluck, Bright Pluck, Marimba, Kalimba, Pizzicato, Synth Harp, Stab Pluck
  - **Brass (5):** Synth Brass, Big Horns, Soft Horn, Brass Stab, 80s Poly Brass
  - **Leads (7):** Super Lead, Classic Lead, Square Lead, Sine Whistle, Screamer, Acid Lead, Chiptune
  - **Bells (7):** Crystal Bell, Tubular Bell, Music Box, Glocken Shimmer, Dark Bell, Celesta, Bell Pad
  - **Chorus Synths (7):** Ensemble Strings, 80s Chorus Poly, Silk Chorus Keys, Chorus Pluck, Warm Chorus Pad, Chorus Bass, Chorus Lead
  - **Atmosphäre & Texturen (9):** Nebula Pad, Dark Drone, Warm Strings, Glass Shimmer, Wind, Ocean Swell, Celestial Choir, Dark Matter, Evolving Pad
  - dazu **Init** als neutraler Startpunkt
- Alle Regler automatisierbar, Einstellungen werden im FL-Projekt gespeichert

## Variante 1: Ohne Programmierkenntnisse (GitHub baut es für dich)

1. Kostenlosen Account auf github.com anlegen und ein neues Repository erstellen.
2. Den kompletten Inhalt dieses Ordners hochladen (inkl. des versteckten Ordners `.github`).
3. Im Repository auf **Actions** klicken – der Build startet automatisch (ca. 10 Minuten).
4. Nach Abschluss unten bei **Artifacts** `NebulaSynth-VST3-windows-latest` (oder `macos-latest`) herunterladen und entpacken.
5. Weiter bei „In FL Studio einbinden“.

## Variante 2: Selbst kompilieren

### Windows
1. **Visual Studio 2022 Community** installieren, mit der Komponente „Desktopentwicklung mit C++“.
2. **CMake** (cmake.org) und **Git** installieren.
3. In diesem Ordner eine Eingabeaufforderung öffnen:
   ```
   cmake -B build -G "Visual Studio 17 2022"
   cmake --build build --config Release
   ```
   Beim ersten Mal lädt CMake das JUCE-Framework automatisch herunter.
4. Ergebnis: `build\NebulaSynth_artefacts\Release\VST3\Nebula Synth.vst3`

### macOS
1. Xcode (App Store) und CMake installieren (`brew install cmake`).
2. Im Terminal:
   ```
   cmake -B build -G Xcode
   cmake --build build --config Release
   ```
3. Ergebnis: `build/NebulaSynth_artefacts/Release/VST3/Nebula Synth.vst3`

Zusätzlich entsteht eine **Standalone-App** zum Testen ohne DAW.

## In FL Studio einbinden

1. `Nebula Synth.vst3` kopieren nach
   - Windows: `C:\Program Files\Common Files\VST3\`
   - macOS: `~/Library/Audio/Plug-Ins/VST3/`
2. FL Studio: **Options → Manage plugins → Find installed plugins** (bzw. „Find more plugins“).
3. Im Plugin-Browser unter *Generators* erscheint **Nebula Synth**.

## Projektstruktur

```
Source/
  Params.h            Alle Parameter (Namen, Bereiche, Standardwerte)
  SynthVoice.h        Klangerzeugung pro Stimme (Oszillatoren, Filter, Hüllkurven, LFO)
  PluginProcessor.*   Plugin-Kern, Effekte, Presets, Speichern/Laden
  PluginEditor.*      Oberfläche
CMakeLists.txt        Build-Konfiguration
```

Ideen zum Erweitern: weitere Presets in `PluginProcessor.cpp` (Funktion `getPresets`), zusätzliche Wellenformen in `SynthVoice.h` (`oscillator`), ein dritter Layer oder ein Wavetable-/Sample-Layer.

Hinweis zur Lizenz: Das Plugin nutzt das JUCE-Framework (AGPLv3 oder kommerzielle JUCE-Lizenz). Für den privaten Gebrauch ist das unproblematisch; wer das Plugin verkaufen oder ohne Quellcode weitergeben will, braucht eine passende JUCE-Lizenz.
