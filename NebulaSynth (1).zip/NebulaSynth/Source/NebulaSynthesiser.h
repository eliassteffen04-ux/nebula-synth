#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <vector>
#include <algorithm>
#include "SynthVoice.h"

// Synthesiser mit drei Stimmen-Modi:
//  Poly   – mehrstimmig, Anzahl Stimmen einstellbar (ältere Stimmen werden übernommen)
//  Mono   – einstimmig, jede neue Note startet die Hüllkurven neu, Glide bei jeder Note
//  Legato – einstimmig, überlappend gespielte Noten gleiten ohne Neustart der Hüllkurven
class NebulaSynthesiser : public juce::Synthesiser
{
public:
    enum Mode { poly = 0, mono = 1, legato = 2 };

    NebulaSynthesiser() { heldNotes.reserve (128); }

    void setParameterSources (std::atomic<float>* modeParam, std::atomic<float>* voicesParam)
    {
        modeSource   = modeParam;
        voicesSource = voicesParam;
    }

    // Wird einmal pro Block aufgerufen; bei Moduswechsel werden alle Noten beendet.
    void updateMode()
    {
        const int newMode = juce::jlimit (0, 2, (int) modeSource->load());
        polyLimit = juce::jlimit (1, getNumVoices(), (int) std::lround (voicesSource->load()));
        if (newMode != mode)
        {
            allNotesOff (0, false);
            heldNotes.clear();
            mode = newMode;
        }
    }

    void noteOn (int midiChannel, int midiNoteNumber, float velocity) override
    {
        if (mode == poly)
        {
            Synthesiser::noteOn (midiChannel, midiNoteNumber, velocity);
            return;
        }

        const juce::ScopedLock sl (lock);
        auto* voice = monoVoice();
        auto* sound = getSound (0).get();
        if (voice == nullptr || sound == nullptr)
            return;

        const bool othersHeld = ! heldNotes.empty();
        removeHeld (midiNoteNumber);
        heldNotes.push_back (midiNoteNumber);

        if (voice->isVoiceActive())
        {
            if (mode == legato && othersHeld)
                voice->glideTo (midiNoteNumber, true);
            else
                voice->retrigger (midiNoteNumber, velocity, mode == mono);
        }
        else
        {
            startVoice (voice, sound, midiChannel, midiNoteNumber, velocity);
        }
    }

    void noteOff (int midiChannel, int midiNoteNumber, float velocity, bool allowTailOff) override
    {
        if (mode == poly)
        {
            Synthesiser::noteOff (midiChannel, midiNoteNumber, velocity, allowTailOff);
            return;
        }

        const juce::ScopedLock sl (lock);
        auto* voice = monoVoice();
        if (voice == nullptr)
            return;

        const bool wasCurrent = ! heldNotes.empty() && heldNotes.back() == midiNoteNumber;
        removeHeld (midiNoteNumber);

        if (! wasCurrent || ! voice->isVoiceActive())
            return;

        if (! heldNotes.empty())
            voice->glideTo (heldNotes.back(), true);   // zurück zur zuletzt gehaltenen Note
        else
            stopVoice (voice, velocity, allowTailOff);
    }

    void allNotesOff (int midiChannel, bool allowTailOff) override
    {
        heldNotes.clear();
        Synthesiser::allNotesOff (midiChannel, allowTailOff);
    }

protected:
    juce::SynthesiserVoice* findFreeVoice (juce::SynthesiserSound* sound, int midiChannel,
                                           int midiNoteNumber, bool stealIfNoneAvailable) const override
    {
        const juce::ScopedLock sl (lock);

        int active = 0;
        for (auto* v : voices)
            if (v->isVoiceActive())
                ++active;

        if (active < polyLimit)
            return Synthesiser::findFreeVoice (sound, midiChannel, midiNoteNumber, stealIfNoneAvailable);

        if (! stealIfNoneAvailable)
            return nullptr;

        // Stimme übernehmen: bevorzugt die älteste losgelassene, sonst die älteste gehaltene
        juce::SynthesiserVoice* oldestReleased = nullptr;
        juce::SynthesiserVoice* oldestHeld = nullptr;
        for (auto* v : voices)
        {
            if (! v->isVoiceActive())
                continue;
            auto*& slot = v->isKeyDown() ? oldestHeld : oldestReleased;
            if (slot == nullptr || v->wasStartedBefore (*slot))
                slot = v;
        }
        return oldestReleased != nullptr ? oldestReleased : oldestHeld;
    }

private:
    NebulaVoice* monoVoice() const
    {
        return dynamic_cast<NebulaVoice*> (getVoice (0));
    }

    void removeHeld (int note)
    {
        heldNotes.erase (std::remove (heldNotes.begin(), heldNotes.end(), note), heldNotes.end());
    }

    std::atomic<float>* modeSource = nullptr;
    std::atomic<float>* voicesSource = nullptr;
    int mode = poly;
    int polyLimit = 16;
    std::vector<int> heldNotes;
};
