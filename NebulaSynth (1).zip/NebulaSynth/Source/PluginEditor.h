#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"

class NebulaLookAndFeel : public juce::LookAndFeel_V4
{
public:
    NebulaLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
};

class NebulaEditor : public juce::AudioProcessorEditor
{
public:
    explicit NebulaEditor (NebulaAudioProcessor&);
    ~NebulaEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using APVTS = juce::AudioProcessorValueTreeState;

    struct Widget
    {
        std::unique_ptr<juce::Slider> slider;
        std::unique_ptr<juce::ComboBox> combo;
        juce::Label label;
        int width = 48;
        std::unique_ptr<APVTS::SliderAttachment> sAtt;
        std::unique_ptr<APVTS::ComboBoxAttachment> cAtt;
    };

    struct Group
    {
        juce::String title;
        std::vector<Widget*> items;
        juce::Rectangle<int> area;
    };

    struct Row
    {
        juce::String title;
        juce::Colour accent;
        juce::ToggleButton* toggle = nullptr;
        std::vector<Group> groups;
        juce::Rectangle<int> area;
    };

    Widget* addKnob (Group&, const juce::String& paramId, const juce::String& name, juce::Colour);
    Widget* addCombo (Group&, const juce::String& paramId, const juce::String& name);
    void buildLayerRow (int layer, juce::Colour accent);
    void buildGlobalRow (juce::Colour accent);

    NebulaAudioProcessor& processor;
    NebulaLookAndFeel lnf;

    std::vector<std::unique_ptr<Widget>> widgets;
    std::vector<Row> rows;

    juce::ToggleButton layerToggles[2];
    std::unique_ptr<APVTS::ButtonAttachment> toggleAtt[2];

    juce::ComboBox presetBox;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NebulaEditor)
};
