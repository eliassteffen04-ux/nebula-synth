#include "PluginEditor.h"
#include <map>

static juce::String u8 (const char* t) { return juce::String::fromUTF8 (t); }

namespace Theme
{
    const juce::Colour background { 0xff12141a };
    const juce::Colour panel      { 0xff1b1e26 };
    const juce::Colour group      { 0xff22252f };
    const juce::Colour track      { 0xff2e323d };
    const juce::Colour knob       { 0xff2a2d37 };
    const juce::Colour text       { 0xffd8dbe3 };
    const juce::Colour dimText    { 0xff8a8f9c };
    const juce::Colour layerA     { 0xff4fd1c5 };
    const juce::Colour layerB     { 0xffa78bfa };
    const juce::Colour global     { 0xfff6ad55 };
}

//==============================================================================
NebulaLookAndFeel::NebulaLookAndFeel()
{
    setColour (juce::ComboBox::backgroundColourId, Theme::knob);
    setColour (juce::ComboBox::outlineColourId,    Theme::track);
    setColour (juce::ComboBox::textColourId,       Theme::text);
    setColour (juce::ComboBox::arrowColourId,      Theme::dimText);
    setColour (juce::PopupMenu::backgroundColourId, Theme::panel);
    setColour (juce::PopupMenu::textColourId,       Theme::text);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, Theme::track);
    setColour (juce::Label::textColourId,           Theme::dimText);
    setColour (juce::ToggleButton::textColourId,    Theme::text);
    setColour (juce::ToggleButton::tickColourId,    Theme::text);
    setColour (juce::BubbleComponent::backgroundColourId, Theme::panel);
    setColour (juce::BubbleComponent::outlineColourId,    Theme::track);
    setColour (juce::TooltipWindow::textColourId,         Theme::text);
}

void NebulaLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                          float startAngle, float endAngle, juce::Slider& s)
{
    auto bounds = juce::Rectangle<int> (x, y, w, h).toFloat().reduced (3.0f);
    const float radius = std::min (bounds.getWidth(), bounds.getHeight()) * 0.5f;
    const auto c = bounds.getCentre();
    const float lineW = 3.0f;
    const float arcR = radius - lineW;
    const auto stroke = juce::PathStrokeType (lineW, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);

    juce::Path bg;
    bg.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, startAngle, endAngle, true);
    g.setColour (Theme::track);
    g.strokePath (bg, stroke);

    // Bipolare Regler (z.B. Pan) starten in der Mitte
    const bool bipolar = s.getMinimum() < 0.0 && s.getMaximum() > 0.0;
    const float angle = startAngle + pos * (endAngle - startAngle);
    const float from = bipolar ? (startAngle + endAngle) * 0.5f : startAngle;

    juce::Path val;
    val.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, std::min (from, angle), std::max (from, angle), true);
    g.setColour (s.findColour (juce::Slider::rotarySliderFillColourId));
    g.strokePath (val, stroke);

    const float kr = arcR - 5.0f;
    g.setColour (Theme::knob);
    g.fillEllipse (c.x - kr, c.y - kr, kr * 2.0f, kr * 2.0f);

    const juce::Point<float> p1 (c.x + kr * 0.35f * std::sin (angle), c.y - kr * 0.35f * std::cos (angle));
    const juce::Point<float> p2 (c.x + (kr - 2.0f) * std::sin (angle), c.y - (kr - 2.0f) * std::cos (angle));
    g.setColour (Theme::text);
    g.drawLine ({ p1, p2 }, 2.0f);
}

//==============================================================================
NebulaEditor::NebulaEditor (NebulaAudioProcessor& p)
    : AudioProcessorEditor (p), processor (p)
{
    setLookAndFeel (&lnf);

    buildLayerRow (0, Theme::layerA);
    buildLayerRow (1, Theme::layerB);
    buildGlobalRow (Theme::global);

    const std::map<juce::String, juce::String> headings {
        { "Bass", "BASS" }, { "Keys", "KEYS" }, { "Pluck", "PLUCKS" },
        { "Bells", "BELLS" }, { "Brass", "BRASS" }, { "Lead", "LEADS" }, { "Chorus", "CHORUS SYNTHS" }, { "Atmo", u8 ("ATMOSPHÄRE & TEXTUREN") } };
    juce::String lastCategory;
    for (int i = 0; i < processor.getNumPrograms(); ++i)
    {
        const auto cat = processor.getPresetCategory (i);
        if (cat != lastCategory && cat.isNotEmpty())
        {
            presetBox.addSeparator();
            presetBox.addSectionHeading (headings.count (cat) ? headings.at (cat) : cat);
        }
        lastCategory = cat;
        presetBox.addItem (processor.getPresetShortName (i), i + 1);
    }
    presetBox.setSelectedItemIndex (processor.getCurrentProgram(), juce::dontSendNotification);
    presetBox.onChange = [this]
    {
        processor.setCurrentProgram (presetBox.getSelectedItemIndex());
        processor.updateHostDisplay();
    };
    addAndMakeVisible (presetBox);

    setSize (1180, 572);
}

NebulaEditor::~NebulaEditor()
{
    setLookAndFeel (nullptr);
}

NebulaEditor::Widget* NebulaEditor::addKnob (Group& grp, const juce::String& paramId,
                                             const juce::String& name, juce::Colour accent)
{
    auto w = std::make_unique<Widget>();
    w->slider = std::make_unique<juce::Slider> (juce::Slider::RotaryHorizontalVerticalDrag, juce::Slider::NoTextBox);
    w->slider->setColour (juce::Slider::rotarySliderFillColourId, accent);
    w->slider->setPopupDisplayEnabled (true, true, this);
    addAndMakeVisible (*w->slider);
    w->sAtt = std::make_unique<APVTS::SliderAttachment> (processor.apvts, paramId, *w->slider);

    w->label.setText (name, juce::dontSendNotification);
    w->label.setJustificationType (juce::Justification::centred);
    w->label.setFont (juce::FontOptions (11.0f));
    addAndMakeVisible (w->label);

    w->width = 48;
    grp.items.push_back (w.get());
    widgets.push_back (std::move (w));
    return widgets.back().get();
}

NebulaEditor::Widget* NebulaEditor::addCombo (Group& grp, const juce::String& paramId, const juce::String& name)
{
    auto w = std::make_unique<Widget>();
    w->combo = std::make_unique<juce::ComboBox>();
    if (auto* choice = dynamic_cast<juce::AudioParameterChoice*> (processor.apvts.getParameter (paramId)))
        w->combo->addItemList (choice->choices, 1);
    addAndMakeVisible (*w->combo);
    w->cAtt = std::make_unique<APVTS::ComboBoxAttachment> (processor.apvts, paramId, *w->combo);

    w->label.setText (name, juce::dontSendNotification);
    w->label.setJustificationType (juce::Justification::centred);
    w->label.setFont (juce::FontOptions (11.0f));
    addAndMakeVisible (w->label);

    w->width = 92;
    grp.items.push_back (w.get());
    widgets.push_back (std::move (w));
    return widgets.back().get();
}

void NebulaEditor::buildLayerRow (int layer, juce::Colour accent)
{
    auto id = [layer] (const char* n) { return Params::layerId (layer, n); };

    Row row;
    row.title  = layer == 0 ? "LAYER A" : "LAYER B";
    row.accent = accent;

    auto& toggle = layerToggles[layer];
    toggle.setButtonText ("Aktiv");
    toggle.setColour (juce::ToggleButton::tickColourId, accent);
    addAndMakeVisible (toggle);
    toggleAtt[layer] = std::make_unique<APVTS::ButtonAttachment> (processor.apvts, id ("on"), toggle);
    row.toggle = &toggle;

    Group osc { "OSZILLATOR", {}, {} };
    addCombo (osc, id ("wave"), "Welle");
    addKnob (osc, id ("octave"), "Oktave", accent);
    addKnob (osc, id ("fine"),   "Fein",   accent);
    addKnob (osc, id ("unison"), "Unison", accent);
    addKnob (osc, id ("detune"), "Detune", accent);
    addKnob (osc, id ("spread"), "Breite", accent);
    addKnob (osc, id ("level"),  "Pegel",  accent);
    addKnob (osc, id ("pan"),    "Pan",    accent);

    Group filter { "FILTER", {}, {} };
    addCombo (filter, id ("ftype"), "Typ");
    addKnob (filter, id ("cutoff"), "Cutoff", accent);
    addKnob (filter, id ("reso"),   "Reso",   accent);
    addKnob (filter, id ("envamt"), "Env",    accent);

    Group amp { u8 ("LAUTSTÄRKE-HÜLLKURVE"), {}, {} };
    addKnob (amp, id ("att"), "A", accent);
    addKnob (amp, id ("dec"), "D", accent);
    addKnob (amp, id ("sus"), "S", accent);
    addKnob (amp, id ("rel"), "R", accent);

    Group fenv { u8 ("FILTER-HÜLLKURVE"), {}, {} };
    addKnob (fenv, id ("fatt"), "A", accent);
    addKnob (fenv, id ("fdec"), "D", accent);
    addKnob (fenv, id ("fsus"), "S", accent);
    addKnob (fenv, id ("frel"), "R", accent);

    row.groups = { std::move (osc), std::move (filter), std::move (amp), std::move (fenv) };
    rows.push_back (std::move (row));
}

void NebulaEditor::buildGlobalRow (juce::Colour accent)
{
    Row row;
    row.title  = "GLOBAL";
    row.accent = accent;

    Group lfo { "LFO", {}, {} };
    addKnob (lfo, "lfo_rate",  "Rate",  accent);
    addKnob (lfo, "lfo_depth", "Tiefe", accent);
    addCombo (lfo, "lfo_target", "Ziel");

    Group voice { "STIMMEN", {}, {} };
    addCombo (voice, "voice_mode", "Modus");
    addKnob (voice, "poly_voices", "Stimmen", accent);
    addKnob (voice, "glide", "Glide", accent);

    Group chorus { "CHORUS", {}, {} };
    addKnob (chorus, "chorus_mix",  "Mix",  accent);
    addKnob (chorus, "chorus_rate", "Rate", accent);

    Group delay { "DELAY", {}, {} };
    addKnob (delay, "delay_time", "Zeit",     accent);
    addKnob (delay, "delay_fb",   "Feedback", accent);
    addKnob (delay, "delay_mix",  "Mix",      accent);

    Group reverb { "REVERB", {}, {} };
    addKnob (reverb, "rev_size", u8 ("Grösse"), accent);
    addKnob (reverb, "rev_damp", u8 ("Dämpf."), accent);
    addKnob (reverb, "rev_mix",  "Mix",    accent);

    Group out { "AUSGANG", {}, {} };
    addKnob (out, "master", "Master", accent);

    row.groups = { std::move (voice), std::move (lfo), std::move (chorus), std::move (delay), std::move (reverb), std::move (out) };
    rows.push_back (std::move (row));
}

void NebulaEditor::paint (juce::Graphics& g)
{
    g.fillAll (Theme::background);

    auto header = getLocalBounds().reduced (12).removeFromTop (44);
    g.setColour (Theme::text);
    g.setFont (juce::FontOptions (26.0f, juce::Font::bold));
    g.drawText ("NEBULA", header.removeFromLeft (130), juce::Justification::centredLeft);
    g.setColour (Theme::dimText);
    g.setFont (juce::FontOptions (13.0f));
    g.drawText ("Layered Synth", header.removeFromLeft (200), juce::Justification::centredLeft);

    for (const auto& row : rows)
    {
        g.setColour (Theme::panel);
        g.fillRoundedRectangle (row.area.toFloat(), 8.0f);

        g.setColour (row.accent);
        g.fillRoundedRectangle (row.area.toFloat().removeFromLeft (4.0f), 2.0f);

        auto titleArea = row.area.reduced (12, 8).removeFromTop (22);
        g.setFont (juce::FontOptions (14.0f, juce::Font::bold));
        g.drawText (row.title, titleArea, juce::Justification::centredLeft);

        for (const auto& grp : row.groups)
        {
            g.setColour (Theme::group);
            g.fillRoundedRectangle (grp.area.toFloat(), 6.0f);
            g.setColour (Theme::dimText);
            g.setFont (juce::FontOptions (10.0f, juce::Font::bold));
            g.drawText (grp.title, grp.area.reduced (8, 4).removeFromTop (14), juce::Justification::centredLeft);
        }
    }
}

void NebulaEditor::resized()
{
    auto area = getLocalBounds().reduced (12);
    auto header = area.removeFromTop (44);
    presetBox.setBounds (header.removeFromRight (220).withSizeKeepingCentre (220, 28));
    area.removeFromTop (8);

    for (auto& row : rows)
    {
        row.area = area.removeFromTop (156);
        area.removeFromTop (10);

        auto inner = row.area.reduced (12, 8);
        auto titleStrip = inner.removeFromTop (22);
        if (row.toggle != nullptr)
            row.toggle->setBounds (titleStrip.withX (titleStrip.getX() + 90).withWidth (90));
        inner.removeFromTop (4);

        for (auto& grp : row.groups)
        {
            int w = 12;
            for (auto* item : grp.items)
                w += item->width;

            w = std::max (w, 84);
            grp.area = inner.removeFromLeft (w);
            inner.removeFromLeft (8);

            auto content = grp.area.reduced (6, 4);
            content.removeFromTop (16);
            for (auto* item : grp.items)
            {
                auto cell = content.removeFromLeft (item->width);
                item->label.setBounds (cell.removeFromBottom (16));
                if (item->slider)
                    item->slider->setBounds (cell.reduced (1));
                else
                    item->combo->setBounds (cell.withSizeKeepingCentre (item->width - 6, 24));
            }
        }
    }
}
