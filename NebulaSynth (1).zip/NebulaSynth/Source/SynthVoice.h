#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <cmath>
#include "Params.h"

struct NebulaSound : public juce::SynthesiserSound
{
    bool appliesToNote (int) override    { return true; }
    bool appliesToChannel (int) override { return true; }
};

class NebulaVoice : public juce::SynthesiserVoice
{
public:
    static constexpr int maxUnison = 7;

    NebulaVoice (const std::array<LayerParams, 2>& lp, const GlobalParams& gp)
        : layerParams (lp), globals (gp) {}

    using juce::SynthesiserVoice::renderNextBlock;

    bool canPlaySound (juce::SynthesiserSound* s) override
    {
        return dynamic_cast<NebulaSound*> (s) != nullptr;
    }

    void prepare (double sampleRate, int blockSize)
    {
        juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) blockSize, 2 };
        for (auto& L : layers)
        {
            L.ampEnv.setSampleRate (sampleRate);
            L.filtEnv.setSampleRate (sampleRate);
            L.filter.prepare (spec);
            L.filter.reset();
        }
    }

    void startNote (int midiNote, float velocity, juce::SynthesiserSound*, int pitchWheel) override
    {
        noteNumber   = midiNote;
        currentPitch = targetPitch = midiNote;
        velocityGain = 0.3f + 0.7f * velocity;
        pitchWheelMoved (pitchWheel);
        lfoPhase = 0.0;

        for (int i = 0; i < 2; ++i)
        {
            auto& L = layers[(size_t) i];
            L.active = layerParams[(size_t) i].on->load() > 0.5f;
            if (! L.active)
                continue;

            for (auto& ph : L.phase)
                ph = rng.nextDouble();

            updateEnvelopes (i);
            L.ampEnv.reset();   L.ampEnv.noteOn();
            L.filtEnv.reset();  L.filtEnv.noteOn();
            L.filter.reset();
            L.lastFiltEnv = 0.0f;
        }

        if (! layers[0].active && ! layers[1].active)
            clearCurrentNote();
    }

    void stopNote (float, bool allowTailOff) override
    {
        if (allowTailOff)
        {
            for (auto& L : layers)
                if (L.active)
                {
                    L.ampEnv.noteOff();
                    L.filtEnv.noteOff();
                }
        }
        else
        {
            for (auto& L : layers)
            {
                L.active = false;
                L.ampEnv.reset();
                L.filtEnv.reset();
            }
            clearCurrentNote();
        }
    }

    // Mono/Legato: Tonhöhe ändern, ohne die Hüllkurven neu zu starten
    void glideTo (int midiNote, bool useGlide)
    {
        noteNumber  = midiNote;
        targetPitch = midiNote;
        if (! useGlide)
            currentPitch = midiNote;
    }

    // Mono: neue Note auf derselben Stimme, Hüllkurven starten vom aktuellen Pegel neu
    void retrigger (int midiNote, float velocity, bool useGlide)
    {
        glideTo (midiNote, useGlide);
        velocityGain = 0.3f + 0.7f * velocity;

        for (int i = 0; i < 2; ++i)
        {
            auto& L = layers[(size_t) i];
            const bool on = layerParams[(size_t) i].on->load() > 0.5f;
            if (! on)
                continue;
            if (! L.active)
            {
                for (auto& ph : L.phase)
                    ph = rng.nextDouble();
                L.ampEnv.reset();
                L.filtEnv.reset();
                L.filter.reset();
            }
            L.active = true;
            updateEnvelopes (i);
            L.ampEnv.noteOn();
            L.filtEnv.noteOn();
        }
    }

    void pitchWheelMoved (int value) override
    {
        pitchBend = (value - 8192) / 8192.0 * 2.0; // +/- 2 Halbtöne
    }

    void controllerMoved (int, int) override {}

    void renderNextBlock (juce::AudioBuffer<float>& out, int start, int num) override
    {
        if (getCurrentlyPlayingNote() < 0)
            return;

        while (num > 0)
        {
            const int n = std::min (num, chunkSize);
            renderChunk (out, start, n);
            start += n;
            num   -= n;

            if (! layers[0].active && ! layers[1].active)
            {
                clearCurrentNote();
                return;
            }
        }
    }

private:
    static constexpr int chunkSize = 32;

    struct Layer
    {
        std::array<double, maxUnison> phase {};
        juce::ADSR ampEnv, filtEnv;
        juce::dsp::StateVariableTPTFilter<float> filter;
        float lastFiltEnv = 0.0f;
        bool active = false;
    };

    static float polyBlep (float t, float dt)
    {
        if (t < dt)        { t /= dt;            return t + t - t * t - 1.0f; }
        if (t > 1.0f - dt) { t = (t - 1.0f) / dt; return t * t + t + t + 1.0f; }
        return 0.0f;
    }

    static float oscillator (int wave, float t, float dt)
    {
        switch (wave)
        {
            case 0: return std::sin (t * juce::MathConstants<float>::twoPi);
            case 1: return 2.0f * t - 1.0f - polyBlep (t, dt);
            case 2:
            {
                float v = t < 0.5f ? 1.0f : -1.0f;
                float t2 = t + 0.5f;
                if (t2 >= 1.0f) t2 -= 1.0f;
                return v + polyBlep (t, dt) - polyBlep (t2, dt);
            }
            case 3: return 4.0f * std::abs (t - 0.5f) - 1.0f;
            default: return 0.0f;
        }
    }

    void updateEnvelopes (int i)
    {
        const auto& p = layerParams[(size_t) i];
        auto& L = layers[(size_t) i];
        L.ampEnv.setParameters  ({ p.att->load(),  p.dec->load(),  p.sus->load(),  p.rel->load() });
        L.filtEnv.setParameters ({ p.fatt->load(), p.fdec->load(), p.fsus->load(), p.frel->load() });
    }

    void renderChunk (juce::AudioBuffer<float>& out, int start, int n)
    {
        const double sr = getSampleRate();
        const float lfoRate   = globals.lfoRate->load();
        const float lfoDepth  = globals.lfoDepth->load();
        const int   lfoTarget = (int) globals.lfoTarget->load();
        const float lfo       = (float) std::sin (lfoPhase * juce::MathConstants<double>::twoPi);
        const float lfoMod    = lfo * lfoDepth;
        lfoPhase += lfoRate * n / sr;
        lfoPhase -= std::floor (lfoPhase);

        // Glide: exponentielle Annäherung, Reglerwert = Zeit bis ca. 95 % erreicht
        const double glideTime = globals.glide->load();
        if (glideTime < 0.001)
            currentPitch = targetPitch;
        else
            currentPitch += (targetPitch - currentPitch) * (1.0 - std::exp (-3.0 * n / (glideTime * sr)));

        float* outL = out.getWritePointer (0, start);
        float* outR = out.getNumChannels() > 1 ? out.getWritePointer (1, start) : nullptr;

        for (int li = 0; li < 2; ++li)
        {
            auto& L = layers[(size_t) li];
            const auto& p = layerParams[(size_t) li];
            if (! L.active)
                continue;

            updateEnvelopes (li);

            const int   wave   = (int) p.wave->load();
            const int   uni    = juce::jlimit (1, maxUnison, (int) std::lround (p.unison->load()));
            const float detune = p.detune->load();
            const float spread = p.spread->load();

            double semis = currentPitch + 12.0 * p.octave->load() + p.fine->load() / 100.0 + pitchBend;
            if (lfoTarget == 1)
                semis += lfoMod; // Vibrato bis +/- 1 Halbton
            const double baseFreq = 440.0 * std::pow (2.0, (semis - 69.0) / 12.0);

            // Unison: Verstimmung bis +/- 50 Cent, Stereo-Verteilung
            std::array<double, maxUnison> inc {};
            std::array<float, maxUnison> gL {}, gR {};
            const float norm = 1.0f / std::sqrt ((float) uni);
            for (int u = 0; u < uni; ++u)
            {
                const float off = uni == 1 ? 0.0f : (2.0f * (float) u / (float) (uni - 1) - 1.0f);
                inc[(size_t) u] = baseFreq * std::pow (2.0, off * detune * 0.5 / 12.0) / sr;
                const float angle = (off * spread + 1.0f) * juce::MathConstants<float>::pi * 0.25f;
                gL[(size_t) u] = std::cos (angle) * juce::MathConstants<float>::sqrt2 * norm;
                gR[(size_t) u] = std::sin (angle) * juce::MathConstants<float>::sqrt2 * norm;
            }

            // Filter
            using FT = juce::dsp::StateVariableTPTFilterType;
            const int ft = (int) p.ftype->load();
            L.filter.setType (ft == 0 ? FT::lowpass : ft == 1 ? FT::bandpass : FT::highpass);
            float octs = p.envAmt->load() * L.lastFiltEnv * 6.0f;
            if (lfoTarget == 0)
                octs += lfoMod * 3.0f;
            const float cutoff = juce::jlimit (20.0f, (float) (sr * 0.45), p.cutoff->load() * std::pow (2.0f, octs));
            L.filter.setCutoffFrequency (cutoff);
            L.filter.setResonance (0.5f * std::pow (24.0f, p.reso->load()));

            // Pegel und Panorama
            float level = p.level->load() * velocityGain * 0.25f;
            if (lfoTarget == 2)
                level *= 1.0f - lfoDepth * 0.5f * (1.0f - lfo);
            float pan = p.pan->load();
            if (lfoTarget == 3)
                pan = juce::jlimit (-1.0f, 1.0f, pan + lfoMod);
            const float pAngle = (pan + 1.0f) * juce::MathConstants<float>::pi * 0.25f;
            const float pl = std::min (1.0f, std::cos (pAngle) * juce::MathConstants<float>::sqrt2);
            const float pr = std::min (1.0f, std::sin (pAngle) * juce::MathConstants<float>::sqrt2);

            for (int s = 0; s < n; ++s)
            {
                float l = 0.0f, r = 0.0f;
                if (wave == 4)
                {
                    l = r = rng.nextFloat() * 2.0f - 1.0f;
                }
                else
                {
                    for (int u = 0; u < uni; ++u)
                    {
                        auto& ph = L.phase[(size_t) u];
                        const float v = oscillator (wave, (float) ph, (float) inc[(size_t) u]);
                        ph += inc[(size_t) u];
                        if (ph >= 1.0) ph -= 1.0;
                        l += v * gL[(size_t) u];
                        r += v * gR[(size_t) u];
                    }
                }

                const float env = L.ampEnv.getNextSample();
                L.lastFiltEnv = L.filtEnv.getNextSample();

                l = L.filter.processSample (0, l);
                r = L.filter.processSample (1, r);

                const float g = env * level;
                if (outR != nullptr)
                {
                    outL[s] += l * g * pl;
                    outR[s] += r * g * pr;
                }
                else
                {
                    outL[s] += 0.5f * (l * pl + r * pr) * g;
                }
            }

            if (! L.ampEnv.isActive())
                L.active = false;
        }
    }

    const std::array<LayerParams, 2>& layerParams;
    const GlobalParams& globals;

    std::array<Layer, 2> layers;
    juce::Random rng;
    int    noteNumber   = 60;
    float  velocityGain = 1.0f;
    double pitchBend    = 0.0;
    double currentPitch = 60.0;
    double targetPitch  = 60.0;
    double lfoPhase     = 0.0;
};
