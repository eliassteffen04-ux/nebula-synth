#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <atomic>

namespace Params
{
    inline juce::String layerId (int layer, const char* name)
    {
        return juce::String (layer == 0 ? "a_" : "b_") + name;
    }

    inline const juce::StringArray waveNames   { "Sine", "Saw", "Square", "Triangle", "Noise" };
    inline const juce::StringArray filterNames { "Lowpass", "Bandpass", "Highpass" };
    inline const juce::StringArray lfoTargets  { "Cutoff", "Pitch", "Volume", "Pan" };
    inline const juce::StringArray voiceModes  { "Poly", "Mono", "Legato" };
    constexpr int maxVoices = 32;

    inline juce::NormalisableRange<float> skewed (float lo, float hi, float centre)
    {
        juce::NormalisableRange<float> r (lo, hi);
        r.setSkewForCentre (centre);
        return r;
    }

    inline juce::AudioProcessorValueTreeState::ParameterLayout createLayout()
    {
        using namespace juce;
        AudioProcessorValueTreeState::ParameterLayout layout;

        auto addFloat = [&] (const String& id, const String& name, NormalisableRange<float> range, float def)
        {
            layout.add (std::make_unique<AudioParameterFloat> (ParameterID { id, 1 }, name, range, def));
        };

        for (int l = 0; l < 2; ++l)
        {
            const String p = l == 0 ? "A " : "B ";
            layout.add (std::make_unique<AudioParameterBool>   (ParameterID { layerId (l, "on"), 1 }, p + "On", l == 0));
            layout.add (std::make_unique<AudioParameterChoice> (ParameterID { layerId (l, "wave"), 1 }, p + "Wave", waveNames, l == 0 ? 1 : 0));
            layout.add (std::make_unique<AudioParameterInt>    (ParameterID { layerId (l, "octave"), 1 }, p + "Octave", -3, 3, 0));
            addFloat (layerId (l, "fine"),   p + "Fine",    { -100.0f, 100.0f }, 0.0f);
            layout.add (std::make_unique<AudioParameterInt>    (ParameterID { layerId (l, "unison"), 1 }, p + "Unison", 1, 7, l == 0 ? 3 : 1));
            addFloat (layerId (l, "detune"), p + "Detune",  { 0.0f, 1.0f }, 0.25f);
            addFloat (layerId (l, "spread"), p + "Spread",  { 0.0f, 1.0f }, 0.5f);
            addFloat (layerId (l, "level"),  p + "Level",   { 0.0f, 1.0f }, l == 0 ? 0.8f : 0.5f);
            addFloat (layerId (l, "pan"),    p + "Pan",     { -1.0f, 1.0f }, 0.0f);

            layout.add (std::make_unique<AudioParameterChoice> (ParameterID { layerId (l, "ftype"), 1 }, p + "Filter Type", filterNames, 0));
            addFloat (layerId (l, "cutoff"), p + "Cutoff",     skewed (20.0f, 20000.0f, 1000.0f), 4000.0f);
            addFloat (layerId (l, "reso"),   p + "Resonance",  { 0.0f, 1.0f }, 0.1f);
            addFloat (layerId (l, "envamt"), p + "Filter Env", { -1.0f, 1.0f }, 0.0f);

            addFloat (layerId (l, "att"), p + "Attack",  skewed (0.001f, 10.0f, 0.5f), 0.01f);
            addFloat (layerId (l, "dec"), p + "Decay",   skewed (0.001f, 10.0f, 0.5f), 0.3f);
            addFloat (layerId (l, "sus"), p + "Sustain", { 0.0f, 1.0f }, 0.8f);
            addFloat (layerId (l, "rel"), p + "Release", skewed (0.001f, 15.0f, 0.8f), 0.4f);

            addFloat (layerId (l, "fatt"), p + "F Attack",  skewed (0.001f, 10.0f, 0.5f), 0.01f);
            addFloat (layerId (l, "fdec"), p + "F Decay",   skewed (0.001f, 10.0f, 0.5f), 0.4f);
            addFloat (layerId (l, "fsus"), p + "F Sustain", { 0.0f, 1.0f }, 0.5f);
            addFloat (layerId (l, "frel"), p + "F Release", skewed (0.001f, 15.0f, 0.8f), 0.5f);
        }

        addFloat ("lfo_rate",  "LFO Rate",  skewed (0.01f, 20.0f, 2.0f), 1.0f);
        addFloat ("lfo_depth", "LFO Depth", { 0.0f, 1.0f }, 0.0f);
        layout.add (std::make_unique<AudioParameterChoice> (ParameterID { "lfo_target", 1 }, "LFO Target", lfoTargets, 0));

        addFloat ("chorus_mix",  "Chorus Mix",  { 0.0f, 1.0f }, 0.0f);
        addFloat ("chorus_rate", "Chorus Rate", skewed (0.05f, 5.0f, 0.8f), 0.8f);

        addFloat ("delay_time", "Delay Time",     skewed (10.0f, 2000.0f, 400.0f), 375.0f);
        addFloat ("delay_fb",   "Delay Feedback", { 0.0f, 0.95f }, 0.35f);
        addFloat ("delay_mix",  "Delay Mix",      { 0.0f, 1.0f }, 0.0f);

        addFloat ("rev_size", "Reverb Size", { 0.0f, 1.0f }, 0.6f);
        addFloat ("rev_damp", "Reverb Damp", { 0.0f, 1.0f }, 0.4f);
        addFloat ("rev_mix",  "Reverb Mix",  { 0.0f, 1.0f }, 0.15f);

        layout.add (std::make_unique<AudioParameterChoice> (ParameterID { "voice_mode", 1 }, "Voice Mode", voiceModes, 0));
        layout.add (std::make_unique<AudioParameterInt>    (ParameterID { "poly_voices", 1 }, "Voices", 1, maxVoices, 16));
        addFloat ("glide", "Glide", skewed (0.0f, 2.0f, 0.25f), 0.0f);

        addFloat ("master", "Master", { -24.0f, 6.0f }, -6.0f);
        return layout;
    }
}

struct LayerParams
{
    std::atomic<float> *on, *wave, *octave, *fine, *unison, *detune, *spread, *level, *pan,
                       *ftype, *cutoff, *reso, *envAmt,
                       *att, *dec, *sus, *rel,
                       *fatt, *fdec, *fsus, *frel;
};

struct GlobalParams
{
    std::atomic<float> *lfoRate, *lfoDepth, *lfoTarget, *glide;
};
