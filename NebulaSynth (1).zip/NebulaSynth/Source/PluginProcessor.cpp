#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    struct PresetValue { const char* id; float value; };
    struct Preset { const char* category; const char* name; std::vector<PresetValue> values; };

    const std::vector<Preset>& getPresets()
    {
        // Werte in echten Einheiten (Choice = Index, Int = Zahl). Nicht genannte Parameter = Standardwert.
        // Wellen: 0 Sine, 1 Saw, 2 Square, 3 Triangle, 4 Noise | Filter: 0 LP, 1 BP, 2 HP
        // LFO-Ziel: 0 Cutoff, 1 Pitch, 2 Volume, 3 Pan
        static const std::vector<Preset> presets
        {
            { "", "Init", {} },

            //================================================================ BASS
            { "Bass", "Sub Deep", {
                { "voice_mode", 1 }, { "glide", 0.03f },
                { "master", -1.0f },
                { "a_wave", 0 }, { "a_octave", -1 }, { "a_unison", 1 }, { "a_cutoff", 20000 }, { "master", 0.0f },
                { "a_att", 0.003f }, { "a_dec", 0.3f }, { "a_sus", 1.0f }, { "a_rel", 0.15f }, { "a_level", 0.9f },
                { "rev_mix", 0.0f } } },
            { "Bass", "Reese", {
                { "voice_mode", 1 }, { "glide", 0.06f },
                { "master", -1.0f },
                { "a_wave", 1 }, { "a_octave", -1 }, { "a_unison", 5 }, { "a_detune", 0.35f }, { "a_spread", 0.3f },
                { "a_cutoff", 900 }, { "a_reso", 0.25f }, { "a_att", 0.005f }, { "a_sus", 1.0f }, { "a_rel", 0.2f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.6f },
                { "b_att", 0.005f }, { "b_sus", 1.0f }, { "b_rel", 0.2f },
                { "lfo_rate", 0.3f }, { "lfo_depth", 0.25f }, { "lfo_target", 0 }, { "rev_mix", 0.0f } } },
            { "Bass", "Acid Squelch", {
                { "voice_mode", 2 }, { "glide", 0.08f },
                { "master", -1.0f },
                { "a_wave", 1 }, { "a_octave", -1 }, { "a_unison", 1 }, { "a_cutoff", 300 }, { "a_reso", 0.8f },
                { "a_envamt", 0.7f }, { "a_fatt", 0.001f }, { "a_fdec", 0.25f }, { "a_fsus", 0.1f }, { "a_frel", 0.2f },
                { "a_att", 0.002f }, { "a_dec", 0.4f }, { "a_sus", 0.7f }, { "a_rel", 0.15f },
                { "delay_mix", 0.15f }, { "delay_time", 250 }, { "delay_fb", 0.3f }, { "rev_mix", 0.05f } } },
            { "Bass", "Pluck Bass", {
                { "master", -1.0f },
                { "a_wave", 2 }, { "a_octave", -1 }, { "a_unison", 1 }, { "a_cutoff", 250 }, { "a_reso", 0.3f },
                { "a_envamt", 0.6f }, { "a_fatt", 0.001f }, { "a_fdec", 0.18f }, { "a_fsus", 0.0f },
                { "a_att", 0.002f }, { "a_dec", 0.5f }, { "a_sus", 0.3f }, { "a_rel", 0.15f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.7f },
                { "b_att", 0.002f }, { "b_dec", 0.6f }, { "b_sus", 0.4f }, { "b_rel", 0.15f }, { "rev_mix", 0.0f } } },
            { "Bass", "Wobble", {
                { "voice_mode", 1 },
                { "master", -1.0f },
                { "a_wave", 1 }, { "a_octave", -1 }, { "a_unison", 3 }, { "a_detune", 0.2f }, { "a_spread", 0.2f },
                { "a_cutoff", 400 }, { "a_reso", 0.6f }, { "a_att", 0.005f }, { "a_sus", 1.0f }, { "a_rel", 0.15f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.6f },
                { "b_att", 0.005f }, { "b_sus", 1.0f }, { "b_rel", 0.15f },
                { "lfo_rate", 4.0f }, { "lfo_depth", 0.7f }, { "lfo_target", 0 }, { "rev_mix", 0.0f } } },
            { "Bass", "Fat Analog", {
                { "master", -1.0f },
                { "a_wave", 1 }, { "a_octave", -1 }, { "a_unison", 1 }, { "a_cutoff", 700 }, { "a_reso", 0.2f },
                { "a_envamt", 0.35f }, { "a_fatt", 0.001f }, { "a_fdec", 0.3f }, { "a_fsus", 0.2f },
                { "a_att", 0.002f }, { "a_sus", 0.9f }, { "a_rel", 0.2f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_fine", 8 }, { "b_level", 0.5f },
                { "b_cutoff", 700 }, { "b_envamt", 0.35f }, { "b_fatt", 0.001f }, { "b_fdec", 0.3f }, { "b_fsus", 0.2f },
                { "b_att", 0.002f }, { "b_sus", 0.9f }, { "b_rel", 0.2f }, { "rev_mix", 0.0f } } },
            { "Bass", "Growl", {
                { "voice_mode", 2 }, { "glide", 0.05f },
                { "master", -1.0f },
                { "a_wave", 2 }, { "a_octave", -1 }, { "a_unison", 3 }, { "a_detune", 0.4f }, { "a_ftype", 1 },
                { "a_cutoff", 600 }, { "a_reso", 0.55f }, { "a_att", 0.005f }, { "a_sus", 1.0f }, { "a_rel", 0.15f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.7f },
                { "b_att", 0.005f }, { "b_sus", 1.0f }, { "b_rel", 0.15f },
                { "lfo_rate", 2.5f }, { "lfo_depth", 0.5f }, { "lfo_target", 0 }, { "rev_mix", 0.0f } } },

            //================================================================ KEYS
            { "Keys", "Electric Piano", {
                { "a_wave", 0 }, { "a_unison", 1 }, { "a_att", 0.002f }, { "a_dec", 1.5f }, { "a_sus", 0.3f }, { "a_rel", 0.5f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.25f }, { "b_cutoff", 3000 },
                { "b_att", 0.002f }, { "b_dec", 0.4f }, { "b_sus", 0.0f }, { "b_rel", 0.3f },
                { "lfo_rate", 4.5f }, { "lfo_depth", 0.2f }, { "lfo_target", 2 },
                { "chorus_mix", 0.3f }, { "rev_mix", 0.2f } } },
            { "Keys", "Soft Rhodes", {
                { "a_wave", 3 }, { "a_unison", 2 }, { "a_detune", 0.08f }, { "a_cutoff", 2000 },
                { "a_envamt", 0.2f }, { "a_fdec", 0.8f }, { "a_fsus", 0.2f },
                { "a_att", 0.003f }, { "a_dec", 2.0f }, { "a_sus", 0.25f }, { "a_rel", 0.6f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.2f },
                { "b_att", 0.002f }, { "b_dec", 0.5f }, { "b_sus", 0.0f }, { "b_rel", 0.4f },
                { "chorus_mix", 0.4f }, { "rev_mix", 0.25f } } },
            { "Keys", "Drawbar Organ", {
                { "a_wave", 0 }, { "a_unison", 1 }, { "a_att", 0.005f }, { "a_dec", 0.1f }, { "a_sus", 1.0f }, { "a_rel", 0.08f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.5f },
                { "b_att", 0.005f }, { "b_dec", 0.1f }, { "b_sus", 1.0f }, { "b_rel", 0.08f },
                { "lfo_rate", 6.0f }, { "lfo_depth", 0.15f }, { "lfo_target", 2 },
                { "chorus_mix", 0.5f }, { "chorus_rate", 1.5f }, { "rev_mix", 0.2f } } },
            { "Keys", "Digital Bell Keys", {
                { "a_wave", 0 }, { "a_octave", 1 }, { "a_unison", 1 }, { "a_att", 0.001f }, { "a_dec", 1.8f }, { "a_sus", 0.0f }, { "a_rel", 1.0f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", 2 }, { "b_unison", 1 }, { "b_level", 0.15f }, { "b_cutoff", 6000 },
                { "b_att", 0.001f }, { "b_dec", 0.6f }, { "b_sus", 0.0f }, { "b_rel", 0.5f },
                { "delay_mix", 0.15f }, { "rev_mix", 0.35f } } },
            { "Keys", "Wurly Grit", {
                { "a_wave", 2 }, { "a_unison", 1 }, { "a_cutoff", 1500 }, { "a_reso", 0.2f },
                { "a_envamt", 0.4f }, { "a_fdec", 0.5f }, { "a_fsus", 0.2f },
                { "a_att", 0.002f }, { "a_dec", 1.2f }, { "a_sus", 0.3f }, { "a_rel", 0.3f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_unison", 1 }, { "b_level", 0.5f },
                { "b_att", 0.002f }, { "b_dec", 1.0f }, { "b_sus", 0.3f }, { "b_rel", 0.3f },
                { "lfo_rate", 5.0f }, { "lfo_depth", 0.15f }, { "lfo_target", 2 },
                { "chorus_mix", 0.2f }, { "rev_mix", 0.15f } } },
            { "Keys", "Dreamy Keys", {
                { "a_wave", 1 }, { "a_unison", 5 }, { "a_detune", 0.2f }, { "a_spread", 0.7f }, { "a_cutoff", 1500 },
                { "a_envamt", 0.25f }, { "a_fdec", 1.0f }, { "a_fsus", 0.3f },
                { "a_att", 0.01f }, { "a_dec", 2.0f }, { "a_sus", 0.4f }, { "a_rel", 1.5f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.3f },
                { "b_dec", 1.5f }, { "b_sus", 0.2f }, { "b_rel", 1.5f },
                { "chorus_mix", 0.4f }, { "delay_mix", 0.2f }, { "delay_time", 500 },
                { "rev_size", 0.8f }, { "rev_mix", 0.4f } } },

            //================================================================ PLUCKS
            { "Pluck", "Glass Pluck", {
                { "a_wave", 3 }, { "a_unison", 2 }, { "a_detune", 0.15f },
                { "a_cutoff", 800 }, { "a_reso", 0.35f }, { "a_envamt", 0.7f },
                { "a_fatt", 0.001f }, { "a_fdec", 0.35f }, { "a_fsus", 0.0f },
                { "a_att", 0.002f }, { "a_dec", 0.6f }, { "a_sus", 0.0f }, { "a_rel", 0.5f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 2 }, { "b_level", 0.3f },
                { "b_att", 0.002f }, { "b_dec", 0.3f }, { "b_sus", 0.0f }, { "b_rel", 0.4f },
                { "delay_mix", 0.3f }, { "delay_time", 300 }, { "rev_mix", 0.35f } } },
            { "Pluck", "Bright Pluck", {
                { "a_wave", 1 }, { "a_unison", 3 }, { "a_detune", 0.2f }, { "a_cutoff", 600 }, { "a_reso", 0.2f },
                { "a_envamt", 0.7f }, { "a_fatt", 0.001f }, { "a_fdec", 0.2f }, { "a_fsus", 0.0f },
                { "a_att", 0.001f }, { "a_dec", 0.45f }, { "a_sus", 0.0f }, { "a_rel", 0.3f },
                { "delay_mix", 0.25f }, { "delay_time", 375 }, { "rev_mix", 0.25f } } },
            { "Pluck", "Marimba", {
                { "a_wave", 0 }, { "a_unison", 1 }, { "a_att", 0.001f }, { "a_dec", 0.5f }, { "a_sus", 0.0f }, { "a_rel", 0.3f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 2 }, { "b_unison", 1 }, { "b_level", 0.25f },
                { "b_att", 0.001f }, { "b_dec", 0.08f }, { "b_sus", 0.0f }, { "b_rel", 0.1f },
                { "rev_mix", 0.2f } } },
            { "Pluck", "Kalimba", {
                { "a_wave", 3 }, { "a_unison", 1 }, { "a_cutoff", 2500 },
                { "a_att", 0.001f }, { "a_dec", 0.8f }, { "a_sus", 0.0f }, { "a_rel", 0.6f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 2 }, { "b_unison", 1 }, { "b_level", 0.2f },
                { "b_att", 0.001f }, { "b_dec", 0.15f }, { "b_sus", 0.0f }, { "b_rel", 0.2f },
                { "delay_mix", 0.15f }, { "rev_mix", 0.3f } } },
            { "Pluck", "Pizzicato", {
                { "a_wave", 1 }, { "a_unison", 3 }, { "a_detune", 0.15f }, { "a_cutoff", 1200 },
                { "a_envamt", 0.5f }, { "a_fatt", 0.001f }, { "a_fdec", 0.15f }, { "a_fsus", 0.0f },
                { "a_att", 0.002f }, { "a_dec", 0.25f }, { "a_sus", 0.0f }, { "a_rel", 0.2f },
                { "rev_size", 0.7f }, { "rev_mix", 0.3f } } },
            { "Pluck", "Synth Harp", {
                { "a_wave", 3 }, { "a_unison", 2 }, { "a_detune", 0.1f },
                { "a_att", 0.001f }, { "a_dec", 1.2f }, { "a_sus", 0.0f }, { "a_rel", 1.2f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.2f }, { "b_cutoff", 1500 },
                { "b_envamt", 0.4f }, { "b_fatt", 0.001f }, { "b_fdec", 0.2f }, { "b_fsus", 0.0f },
                { "b_att", 0.001f }, { "b_dec", 0.3f }, { "b_sus", 0.0f }, { "b_rel", 0.3f },
                { "delay_mix", 0.3f }, { "delay_time", 333 }, { "rev_size", 0.8f }, { "rev_mix", 0.4f } } },
            { "Pluck", "Stab Pluck", {
                { "a_wave", 2 }, { "a_unison", 5 }, { "a_detune", 0.3f }, { "a_spread", 0.8f },
                { "a_cutoff", 900 }, { "a_reso", 0.3f }, { "a_envamt", 0.6f }, { "a_fatt", 0.001f }, { "a_fdec", 0.12f }, { "a_fsus", 0.0f },
                { "a_att", 0.001f }, { "a_dec", 0.2f }, { "a_sus", 0.0f }, { "a_rel", 0.15f },
                { "delay_mix", 0.2f }, { "delay_time", 250 }, { "rev_mix", 0.2f } } },

            //================================================================ BRASS
            { "Brass", "Synth Brass", {
                { "a_wave", 1 }, { "a_unison", 3 }, { "a_detune", 0.15f }, { "a_cutoff", 700 }, { "a_reso", 0.15f },
                { "a_envamt", 0.5f }, { "a_fatt", 0.08f }, { "a_fdec", 0.5f }, { "a_fsus", 0.4f }, { "a_frel", 0.3f },
                { "a_att", 0.04f }, { "a_dec", 0.3f }, { "a_sus", 0.85f }, { "a_rel", 0.3f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.35f }, { "b_cutoff", 900 },
                { "b_envamt", 0.5f }, { "b_fatt", 0.08f }, { "b_fdec", 0.5f }, { "b_fsus", 0.4f },
                { "b_att", 0.04f }, { "b_sus", 0.85f }, { "b_rel", 0.3f },
                { "lfo_rate", 5.0f }, { "lfo_depth", 0.05f }, { "lfo_target", 1 }, { "rev_mix", 0.2f } } },
            { "Brass", "Big Horns", {
                { "a_wave", 1 }, { "a_unison", 5 }, { "a_detune", 0.25f }, { "a_spread", 0.6f }, { "a_cutoff", 900 },
                { "a_envamt", 0.4f }, { "a_fatt", 0.12f }, { "a_fdec", 0.6f }, { "a_fsus", 0.5f },
                { "a_att", 0.08f }, { "a_sus", 0.9f }, { "a_rel", 0.4f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.3f }, { "b_cutoff", 1200 },
                { "b_att", 0.08f }, { "b_sus", 0.9f }, { "b_rel", 0.4f },
                { "chorus_mix", 0.2f }, { "rev_size", 0.75f }, { "rev_mix", 0.3f } } },
            { "Brass", "Soft Horn", {
                { "a_wave", 3 }, { "a_unison", 2 }, { "a_detune", 0.1f }, { "a_cutoff", 1100 },
                { "a_envamt", 0.25f }, { "a_fatt", 0.2f }, { "a_fdec", 0.8f }, { "a_fsus", 0.6f },
                { "a_att", 0.12f }, { "a_dec", 0.5f }, { "a_sus", 0.85f }, { "a_rel", 0.5f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_unison", 1 }, { "b_level", 0.25f }, { "b_cutoff", 800 },
                { "b_att", 0.15f }, { "b_sus", 0.85f }, { "b_rel", 0.5f }, { "rev_mix", 0.35f } } },
            { "Brass", "Brass Stab", {
                { "a_wave", 1 }, { "a_unison", 5 }, { "a_detune", 0.3f }, { "a_spread", 0.7f }, { "a_cutoff", 500 }, { "a_reso", 0.2f },
                { "a_envamt", 0.6f }, { "a_fatt", 0.01f }, { "a_fdec", 0.25f }, { "a_fsus", 0.1f },
                { "a_att", 0.005f }, { "a_dec", 0.35f }, { "a_sus", 0.2f }, { "a_rel", 0.25f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.4f }, { "b_cutoff", 600 },
                { "b_envamt", 0.5f }, { "b_fatt", 0.01f }, { "b_fdec", 0.25f }, { "b_fsus", 0.1f },
                { "b_att", 0.005f }, { "b_dec", 0.35f }, { "b_sus", 0.2f }, { "b_rel", 0.25f }, { "rev_mix", 0.25f } } },
            { "Brass", "80s Poly Brass", {
                { "a_wave", 1 }, { "a_unison", 2 }, { "a_detune", 0.2f }, { "a_cutoff", 600 },
                { "a_envamt", 0.55f }, { "a_fatt", 0.05f }, { "a_fdec", 0.7f }, { "a_fsus", 0.35f },
                { "a_att", 0.03f }, { "a_sus", 0.9f }, { "a_rel", 0.35f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_unison", 1 }, { "b_level", 0.3f }, { "b_cutoff", 1500 },
                { "b_att", 0.03f }, { "b_sus", 0.9f }, { "b_rel", 0.35f },
                { "chorus_mix", 0.45f }, { "chorus_rate", 0.6f }, { "rev_mix", 0.25f } } },

            //================================================================ LEADS
            { "Lead", "Super Lead", {
                { "a_wave", 1 }, { "a_unison", 7 }, { "a_detune", 0.35f }, { "a_spread", 0.6f },
                { "a_cutoff", 6000 }, { "a_reso", 0.25f }, { "a_att", 0.005f }, { "a_rel", 0.25f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", -1 }, { "b_level", 0.5f }, { "b_cutoff", 3000 },
                { "b_att", 0.005f }, { "b_rel", 0.25f },
                { "lfo_rate", 5.5f }, { "lfo_depth", 0.08f }, { "lfo_target", 1 },
                { "delay_mix", 0.25f }, { "delay_time", 375 }, { "rev_mix", 0.2f } } },
            { "Lead", "Classic Lead", {
                { "voice_mode", 1 }, { "glide", 0.05f },
                { "a_wave", 1 }, { "a_unison", 1 }, { "a_cutoff", 2500 }, { "a_reso", 0.3f },
                { "a_envamt", 0.3f }, { "a_fdec", 0.3f }, { "a_fsus", 0.4f }, { "a_att", 0.003f }, { "a_sus", 0.9f }, { "a_rel", 0.2f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.4f }, { "b_cutoff", 2500 },
                { "b_att", 0.003f }, { "b_sus", 0.9f }, { "b_rel", 0.2f },
                { "lfo_rate", 5.5f }, { "lfo_depth", 0.06f }, { "lfo_target", 1 },
                { "delay_mix", 0.2f }, { "delay_time", 375 }, { "rev_mix", 0.15f } } },
            { "Lead", "Square Lead", {
                { "voice_mode", 1 }, { "glide", 0.04f },
                { "a_wave", 2 }, { "a_unison", 1 }, { "a_cutoff", 3500 }, { "a_reso", 0.15f },
                { "a_att", 0.003f }, { "a_sus", 0.9f }, { "a_rel", 0.2f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_fine", 7 }, { "b_level", 0.3f },
                { "b_att", 0.003f }, { "b_sus", 0.9f }, { "b_rel", 0.2f },
                { "lfo_rate", 5.0f }, { "lfo_depth", 0.05f }, { "lfo_target", 1 },
                { "delay_mix", 0.25f }, { "rev_mix", 0.2f } } },
            { "Lead", "Sine Whistle", {
                { "voice_mode", 2 }, { "glide", 0.15f },
                { "a_wave", 0 }, { "a_octave", 1 }, { "a_unison", 1 }, { "a_att", 0.03f }, { "a_sus", 1.0f }, { "a_rel", 0.3f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_fine", 10 }, { "b_level", 0.3f },
                { "b_att", 0.03f }, { "b_sus", 1.0f }, { "b_rel", 0.3f },
                { "lfo_rate", 6.0f }, { "lfo_depth", 0.1f }, { "lfo_target", 1 },
                { "delay_mix", 0.3f }, { "delay_time", 500 }, { "delay_fb", 0.4f }, { "rev_mix", 0.3f } } },
            { "Lead", "Screamer", {
                { "voice_mode", 2 }, { "glide", 0.06f },
                { "a_wave", 1 }, { "a_unison", 7 }, { "a_detune", 0.5f }, { "a_spread", 0.9f }, { "a_cutoff", 5000 }, { "a_reso", 0.5f },
                { "a_att", 0.003f }, { "a_sus", 1.0f }, { "a_rel", 0.25f }, { "a_level", 0.7f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", 1 }, { "b_unison", 3 }, { "b_detune", 0.3f }, { "b_level", 0.35f },
                { "b_cutoff", 6000 }, { "b_att", 0.003f }, { "b_sus", 1.0f }, { "b_rel", 0.25f },
                { "lfo_rate", 0.3f }, { "lfo_depth", 0.15f }, { "lfo_target", 0 },
                { "delay_mix", 0.2f }, { "rev_mix", 0.25f } } },
            { "Lead", "Acid Lead", {
                { "voice_mode", 2 }, { "glide", 0.1f },
                { "a_wave", 1 }, { "a_unison", 1 }, { "a_cutoff", 600 }, { "a_reso", 0.75f },
                { "a_envamt", 0.6f }, { "a_fatt", 0.001f }, { "a_fdec", 0.3f }, { "a_fsus", 0.25f },
                { "a_att", 0.002f }, { "a_sus", 0.9f }, { "a_rel", 0.15f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.3f },
                { "b_cutoff", 800 }, { "b_reso", 0.5f }, { "b_att", 0.002f }, { "b_sus", 0.9f }, { "b_rel", 0.15f },
                { "delay_mix", 0.3f }, { "delay_time", 250 }, { "delay_fb", 0.45f }, { "rev_mix", 0.15f } } },
            { "Lead", "Chiptune", {
                { "voice_mode", 1 },
                { "a_wave", 2 }, { "a_unison", 1 }, { "a_cutoff", 20000 }, { "a_reso", 0.0f },
                { "a_att", 0.001f }, { "a_dec", 0.1f }, { "a_sus", 0.9f }, { "a_rel", 0.05f }, { "a_level", 0.6f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.2f }, { "b_cutoff", 20000 },
                { "b_att", 0.001f }, { "b_sus", 0.9f }, { "b_rel", 0.05f },
                { "lfo_rate", 7.0f }, { "lfo_depth", 0.15f }, { "lfo_target", 1 }, { "rev_mix", 0.05f } } },

            //================================================================ BELLS
            { "Bells", "Crystal Bell", {
                { "a_wave", 0 }, { "a_octave", 1 }, { "a_unison", 1 },
                { "a_att", 0.001f }, { "a_dec", 2.5f }, { "a_sus", 0.0f }, { "a_rel", 2.5f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 3 }, { "b_fine", 40 }, { "b_unison", 1 }, { "b_level", 0.35f },
                { "b_att", 0.001f }, { "b_dec", 0.8f }, { "b_sus", 0.0f }, { "b_rel", 0.8f },
                { "delay_mix", 0.2f }, { "delay_time", 500 }, { "rev_size", 0.85f }, { "rev_mix", 0.4f } } },
            { "Bells", "Tubular Bell", {
                { "a_wave", 3 }, { "a_unison", 2 }, { "a_detune", 0.05f }, { "a_cutoff", 4000 },
                { "a_att", 0.001f }, { "a_dec", 4.0f }, { "a_sus", 0.0f }, { "a_rel", 4.0f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 2 }, { "b_fine", -30 }, { "b_unison", 1 }, { "b_level", 0.3f },
                { "b_att", 0.001f }, { "b_dec", 1.5f }, { "b_sus", 0.0f }, { "b_rel", 1.5f },
                { "rev_size", 0.9f }, { "rev_mix", 0.5f } } },
            { "Bells", "Music Box", {
                { "a_wave", 0 }, { "a_octave", 2 }, { "a_unison", 1 },
                { "a_att", 0.001f }, { "a_dec", 0.9f }, { "a_sus", 0.0f }, { "a_rel", 0.9f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", 3 }, { "b_unison", 1 }, { "b_level", 0.2f },
                { "b_att", 0.001f }, { "b_dec", 0.25f }, { "b_sus", 0.0f }, { "b_rel", 0.3f },
                { "delay_mix", 0.1f }, { "rev_mix", 0.3f } } },
            { "Bells", "Glocken Shimmer", {
                { "a_wave", 0 }, { "a_octave", 1 }, { "a_unison", 3 }, { "a_detune", 0.1f }, { "a_spread", 1.0f },
                { "a_att", 0.001f }, { "a_dec", 3.0f }, { "a_sus", 0.0f }, { "a_rel", 3.0f },
                { "b_on", 1 }, { "b_wave", 2 }, { "b_octave", 2 }, { "b_fine", 20 }, { "b_unison", 1 }, { "b_level", 0.12f },
                { "b_ftype", 2 }, { "b_cutoff", 3000 }, { "b_att", 0.001f }, { "b_dec", 1.0f }, { "b_sus", 0.0f }, { "b_rel", 1.0f },
                { "lfo_rate", 5.0f }, { "lfo_depth", 0.15f }, { "lfo_target", 2 },
                { "chorus_mix", 0.3f }, { "delay_mix", 0.3f }, { "delay_time", 600 }, { "delay_fb", 0.5f },
                { "rev_size", 0.9f }, { "rev_mix", 0.55f } } },
            { "Bells", "Dark Bell", {
                { "a_wave", 0 }, { "a_unison", 1 },
                { "a_att", 0.001f }, { "a_dec", 3.0f }, { "a_sus", 0.0f }, { "a_rel", 3.0f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", 1 }, { "b_fine", 35 }, { "b_unison", 1 }, { "b_level", 0.4f },
                { "b_cutoff", 1500 }, { "b_att", 0.001f }, { "b_dec", 1.2f }, { "b_sus", 0.0f }, { "b_rel", 1.2f },
                { "rev_size", 0.8f }, { "rev_mix", 0.45f } } },
            { "Bells", "Celesta", {
                { "a_wave", 0 }, { "a_octave", 1 }, { "a_unison", 1 },
                { "a_att", 0.001f }, { "a_dec", 1.2f }, { "a_sus", 0.0f }, { "a_rel", 0.8f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 2 }, { "b_fine", 5 }, { "b_unison", 1 }, { "b_level", 0.3f },
                { "b_att", 0.001f }, { "b_dec", 0.4f }, { "b_sus", 0.0f }, { "b_rel", 0.4f },
                { "chorus_mix", 0.2f }, { "rev_mix", 0.35f } } },
            { "Bells", "Bell Pad", {
                { "a_wave", 0 }, { "a_octave", 1 }, { "a_unison", 3 }, { "a_detune", 0.15f }, { "a_spread", 0.8f },
                { "a_att", 0.001f }, { "a_dec", 2.0f }, { "a_sus", 0.35f }, { "a_rel", 3.0f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", 2 }, { "b_unison", 1 }, { "b_level", 0.25f },
                { "b_att", 0.001f }, { "b_dec", 0.8f }, { "b_sus", 0.0f }, { "b_rel", 1.0f },
                { "chorus_mix", 0.4f }, { "delay_mix", 0.2f }, { "rev_size", 0.9f }, { "rev_mix", 0.5f } } },

            //================================================================ CHORUS SYNTHS
            { "Chorus", "Ensemble Strings", {
                { "a_wave", 1 }, { "a_unison", 3 }, { "a_detune", 0.12f }, { "a_spread", 0.6f }, { "a_cutoff", 2500 },
                { "a_att", 0.4f }, { "a_sus", 0.9f }, { "a_rel", 1.2f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.3f }, { "b_cutoff", 3000 },
                { "b_att", 0.5f }, { "b_sus", 0.9f }, { "b_rel", 1.2f },
                { "chorus_mix", 1.0f }, { "chorus_rate", 0.5f }, { "rev_mix", 0.35f } } },
            { "Chorus", "80s Chorus Poly", {
                { "a_wave", 2 }, { "a_unison", 1 }, { "a_cutoff", 1800 }, { "a_reso", 0.2f },
                { "a_envamt", 0.35f }, { "a_fdec", 0.6f }, { "a_fsus", 0.3f },
                { "a_att", 0.01f }, { "a_sus", 0.8f }, { "a_rel", 0.6f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_unison", 1 }, { "b_fine", 6 }, { "b_level", 0.5f }, { "b_cutoff", 1800 },
                { "b_envamt", 0.35f }, { "b_fdec", 0.6f }, { "b_fsus", 0.3f },
                { "b_att", 0.01f }, { "b_sus", 0.8f }, { "b_rel", 0.6f },
                { "chorus_mix", 0.9f }, { "chorus_rate", 0.7f }, { "delay_mix", 0.15f }, { "rev_mix", 0.25f } } },
            { "Chorus", "Silk Chorus Keys", {
                { "a_wave", 3 }, { "a_unison", 1 }, { "a_att", 0.002f }, { "a_dec", 1.4f }, { "a_sus", 0.35f }, { "a_rel", 0.7f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.2f }, { "b_cutoff", 2000 },
                { "b_envamt", 0.3f }, { "b_fatt", 0.001f }, { "b_fdec", 0.4f }, { "b_fsus", 0.0f },
                { "b_att", 0.002f }, { "b_dec", 0.5f }, { "b_sus", 0.0f }, { "b_rel", 0.4f },
                { "chorus_mix", 0.85f }, { "chorus_rate", 1.2f }, { "rev_mix", 0.3f } } },
            { "Chorus", "Chorus Pluck", {
                { "a_wave", 1 }, { "a_unison", 2 }, { "a_detune", 0.1f }, { "a_cutoff", 700 },
                { "a_envamt", 0.65f }, { "a_fatt", 0.001f }, { "a_fdec", 0.25f }, { "a_fsus", 0.0f },
                { "a_att", 0.001f }, { "a_dec", 0.5f }, { "a_sus", 0.0f }, { "a_rel", 0.4f },
                { "chorus_mix", 1.0f }, { "chorus_rate", 0.9f },
                { "delay_mix", 0.25f }, { "delay_time", 375 }, { "rev_mix", 0.3f } } },
            { "Chorus", "Warm Chorus Pad", {
                { "a_wave", 1 }, { "a_unison", 3 }, { "a_detune", 0.15f }, { "a_cutoff", 1400 }, { "a_reso", 0.15f },
                { "a_att", 0.9f }, { "a_sus", 1.0f }, { "a_rel", 2.5f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.4f },
                { "b_att", 1.0f }, { "b_sus", 1.0f }, { "b_rel", 2.5f },
                { "lfo_rate", 0.15f }, { "lfo_depth", 0.2f }, { "lfo_target", 0 },
                { "chorus_mix", 1.0f }, { "chorus_rate", 0.35f }, { "rev_size", 0.85f }, { "rev_mix", 0.45f } } },
            { "Chorus", "Chorus Bass", {
                { "voice_mode", 1 }, { "master", -1.0f },
                { "a_wave", 1 }, { "a_octave", -1 }, { "a_unison", 1 }, { "a_cutoff", 600 },
                { "a_envamt", 0.4f }, { "a_fatt", 0.001f }, { "a_fdec", 0.3f }, { "a_fsus", 0.2f },
                { "a_att", 0.002f }, { "a_sus", 0.9f }, { "a_rel", 0.2f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.6f },
                { "b_att", 0.002f }, { "b_sus", 1.0f }, { "b_rel", 0.2f },
                { "chorus_mix", 0.7f }, { "chorus_rate", 0.6f }, { "rev_mix", 0.0f } } },
            { "Chorus", "Chorus Lead", {
                { "voice_mode", 2 }, { "glide", 0.08f },
                { "a_wave", 2 }, { "a_unison", 1 }, { "a_cutoff", 3000 }, { "a_att", 0.01f }, { "a_sus", 0.9f }, { "a_rel", 0.3f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", 1 }, { "b_unison", 1 }, { "b_level", 0.25f },
                { "b_att", 0.01f }, { "b_sus", 0.9f }, { "b_rel", 0.3f },
                { "chorus_mix", 0.9f }, { "chorus_rate", 1.6f },
                { "delay_mix", 0.3f }, { "delay_time", 500 }, { "delay_fb", 0.45f }, { "rev_mix", 0.3f } } },

            //================================================================ ATMOSPHÄRE
            { "Atmo", "Nebula Pad", {
                { "a_wave", 1 }, { "a_unison", 5 }, { "a_detune", 0.4f }, { "a_spread", 0.8f },
                { "a_cutoff", 1800 }, { "a_reso", 0.2f }, { "a_envamt", 0.2f }, { "a_fatt", 2.0f }, { "a_fsus", 0.6f },
                { "a_att", 1.2f }, { "a_dec", 1.0f }, { "a_sus", 0.85f }, { "a_rel", 2.5f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", 1 }, { "b_level", 0.4f }, { "b_cutoff", 5000 },
                { "b_att", 1.5f }, { "b_rel", 3.0f },
                { "lfo_rate", 0.2f }, { "lfo_depth", 0.3f }, { "lfo_target", 0 },
                { "chorus_mix", 0.35f }, { "delay_mix", 0.25f }, { "delay_time", 500 },
                { "rev_size", 0.85f }, { "rev_mix", 0.45f } } },
            { "Atmo", "Dark Drone", {
                { "a_wave", 1 }, { "a_octave", -1 }, { "a_unison", 3 }, { "a_detune", 0.3f },
                { "a_cutoff", 400 }, { "a_reso", 0.5f }, { "a_att", 2.0f }, { "a_sus", 1.0f }, { "a_rel", 4.0f },
                { "b_on", 1 }, { "b_wave", 4 }, { "b_level", 0.15f }, { "b_ftype", 1 }, { "b_cutoff", 1200 },
                { "b_reso", 0.6f }, { "b_att", 3.0f }, { "b_sus", 1.0f }, { "b_rel", 4.0f },
                { "lfo_rate", 0.07f }, { "lfo_depth", 0.5f }, { "lfo_target", 0 },
                { "chorus_mix", 0.2f }, { "rev_size", 0.95f }, { "rev_mix", 0.6f } } },
            { "Atmo", "Warm Strings", {
                { "a_wave", 1 }, { "a_unison", 7 }, { "a_detune", 0.3f }, { "a_spread", 1.0f }, { "a_cutoff", 2200 },
                { "a_att", 0.8f }, { "a_dec", 1.0f }, { "a_sus", 0.9f }, { "a_rel", 2.0f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_octave", 1 }, { "b_unison", 3 }, { "b_detune", 0.25f }, { "b_level", 0.3f },
                { "b_cutoff", 3000 }, { "b_att", 1.0f }, { "b_sus", 0.9f }, { "b_rel", 2.0f },
                { "chorus_mix", 0.4f }, { "rev_size", 0.85f }, { "rev_mix", 0.4f } } },
            { "Atmo", "Glass Shimmer", {
                { "a_wave", 3 }, { "a_octave", 1 }, { "a_unison", 5 }, { "a_detune", 0.15f }, { "a_spread", 1.0f }, { "a_cutoff", 6000 },
                { "a_att", 1.5f }, { "a_sus", 1.0f }, { "a_rel", 4.0f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 2 }, { "b_unison", 3 }, { "b_level", 0.35f },
                { "b_att", 2.0f }, { "b_sus", 1.0f }, { "b_rel", 4.0f },
                { "lfo_rate", 3.0f }, { "lfo_depth", 0.25f }, { "lfo_target", 2 },
                { "delay_mix", 0.35f }, { "delay_time", 600 }, { "delay_fb", 0.55f },
                { "rev_size", 0.95f }, { "rev_mix", 0.6f } } },
            { "Atmo", "Wind", {
                { "a_wave", 4 }, { "a_ftype", 1 }, { "a_cutoff", 900 }, { "a_reso", 0.75f }, { "a_level", 1.0f },
                { "a_att", 2.0f }, { "a_sus", 1.0f }, { "a_rel", 3.0f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", -1 }, { "b_unison", 1 }, { "b_level", 0.2f },
                { "b_att", 2.5f }, { "b_sus", 1.0f }, { "b_rel", 3.0f },
                { "lfo_rate", 0.1f }, { "lfo_depth", 0.6f }, { "lfo_target", 0 },
                { "rev_size", 0.9f }, { "rev_mix", 0.5f } } },
            { "Atmo", "Ocean Swell", {
                { "a_wave", 4 }, { "a_cutoff", 500 }, { "a_reso", 0.3f }, { "a_level", 0.9f },
                { "a_envamt", 0.5f }, { "a_fatt", 3.0f }, { "a_fdec", 3.0f }, { "a_fsus", 0.3f }, { "a_frel", 3.0f },
                { "a_att", 3.0f }, { "a_dec", 3.0f }, { "a_sus", 0.5f }, { "a_rel", 4.0f },
                { "b_on", 1 }, { "b_wave", 1 }, { "b_unison", 5 }, { "b_detune", 0.4f }, { "b_level", 0.3f }, { "b_cutoff", 600 },
                { "b_att", 4.0f }, { "b_sus", 1.0f }, { "b_rel", 4.0f },
                { "lfo_rate", 0.08f }, { "lfo_depth", 0.5f }, { "lfo_target", 0 },
                { "chorus_mix", 0.3f }, { "rev_size", 0.95f }, { "rev_mix", 0.55f } } },
            { "Atmo", "Celestial Choir", {
                { "a_wave", 3 }, { "a_unison", 7 }, { "a_detune", 0.35f }, { "a_spread", 1.0f },
                { "a_ftype", 1 }, { "a_cutoff", 1100 }, { "a_reso", 0.4f }, { "a_level", 1.0f },
                { "a_att", 1.2f }, { "a_sus", 1.0f }, { "a_rel", 3.0f },
                { "b_on", 1 }, { "b_wave", 0 }, { "b_octave", 1 }, { "b_unison", 3 }, { "b_detune", 0.2f }, { "b_level", 0.3f },
                { "b_att", 1.5f }, { "b_sus", 1.0f }, { "b_rel", 3.0f },
                { "lfo_rate", 0.25f }, { "lfo_depth", 0.08f }, { "lfo_target", 1 },
                { "chorus_mix", 0.5f }, { "rev_size", 0.9f }, { "rev_mix", 0.55f } } },
            { "Atmo", "Dark Matter", {
                { "a_wave", 2 }, { "a_octave", -2 }, { "a_unison", 5 }, { "a_detune", 0.45f }, { "a_spread", 1.0f },
                { "a_cutoff", 250 }, { "a_reso", 0.6f }, { "a_att", 3.0f }, { "a_sus", 1.0f }, { "a_rel", 5.0f },
                { "b_on", 1 }, { "b_wave", 4 }, { "b_level", 0.1f }, { "b_ftype", 2 }, { "b_cutoff", 4000 },
                { "b_att", 4.0f }, { "b_sus", 1.0f }, { "b_rel", 5.0f },
                { "lfo_rate", 0.05f }, { "lfo_depth", 0.6f }, { "lfo_target", 0 },
                { "delay_mix", 0.25f }, { "delay_time", 900 }, { "delay_fb", 0.6f },
                { "rev_size", 0.95f }, { "rev_mix", 0.65f } } },
            { "Atmo", "Evolving Pad", {
                { "a_wave", 1 }, { "a_unison", 5 }, { "a_detune", 0.3f }, { "a_spread", 0.9f }, { "a_cutoff", 500 }, { "a_reso", 0.35f },
                { "a_envamt", 0.5f }, { "a_fatt", 4.0f }, { "a_fdec", 4.0f }, { "a_fsus", 0.4f }, { "a_frel", 4.0f },
                { "a_att", 2.0f }, { "a_sus", 1.0f }, { "a_rel", 4.0f },
                { "b_on", 1 }, { "b_wave", 3 }, { "b_octave", 1 }, { "b_unison", 3 }, { "b_level", 0.35f }, { "b_cutoff", 2000 },
                { "b_att", 3.0f }, { "b_sus", 1.0f }, { "b_rel", 4.0f },
                { "lfo_rate", 0.15f }, { "lfo_depth", 0.6f }, { "lfo_target", 3 },
                { "chorus_mix", 0.3f }, { "delay_mix", 0.2f }, { "delay_time", 700 }, { "delay_fb", 0.5f },
                { "rev_size", 0.9f }, { "rev_mix", 0.5f } } },
        };
        return presets;
    }
}

NebulaAudioProcessor::NebulaAudioProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "NebulaState", Params::createLayout())
{
    auto get = [this] (const juce::String& id) { return apvts.getRawParameterValue (id); };

    for (int l = 0; l < 2; ++l)
    {
        auto id = [l] (const char* n) { return Params::layerId (l, n); };
        layerParams[(size_t) l] = {
            get (id ("on")), get (id ("wave")), get (id ("octave")), get (id ("fine")),
            get (id ("unison")), get (id ("detune")), get (id ("spread")), get (id ("level")), get (id ("pan")),
            get (id ("ftype")), get (id ("cutoff")), get (id ("reso")), get (id ("envamt")),
            get (id ("att")), get (id ("dec")), get (id ("sus")), get (id ("rel")),
            get (id ("fatt")), get (id ("fdec")), get (id ("fsus")), get (id ("frel")) };
    }
    globals = { get ("lfo_rate"), get ("lfo_depth"), get ("lfo_target"), get ("glide") };

    chorusMix  = get ("chorus_mix");
    chorusRate = get ("chorus_rate");
    delayTime  = get ("delay_time");
    delayFb    = get ("delay_fb");
    delayMix   = get ("delay_mix");
    revSize    = get ("rev_size");
    revDamp    = get ("rev_damp");
    revMix     = get ("rev_mix");
    master     = get ("master");

    for (int i = 0; i < Params::maxVoices; ++i)
        synth.addVoice (new NebulaVoice (layerParams, globals));
    synth.addSound (new NebulaSound());
    synth.setParameterSources (get ("voice_mode"), get ("poly_voices"));
}

bool NebulaAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    return out == juce::AudioChannelSet::stereo() || out == juce::AudioChannelSet::mono();
}

void NebulaAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    synth.setCurrentPlaybackSampleRate (sampleRate);
    for (int i = 0; i < synth.getNumVoices(); ++i)
        if (auto* v = dynamic_cast<NebulaVoice*> (synth.getVoice (i)))
            v->prepare (sampleRate, samplesPerBlock);

    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock,
                                  (juce::uint32) std::max (1, getTotalNumOutputChannels()) };
    chorus.prepare (spec);
    chorus.setCentreDelay (8.0f);
    chorus.setDepth (0.35f);
    chorus.setFeedback (0.15f);

    reverb.prepare (spec);
    reverb.reset();

    delay.setMaximumDelayInSamples ((int) (sampleRate * 2.1));
    delay.prepare (spec);
    delay.reset();
    delaySamples.reset (sampleRate, 0.08);
    delaySamples.setCurrentAndTargetValue (delayTime->load() * 0.001f * (float) sampleRate);
}

void NebulaAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    const int numSamples  = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();
    synth.updateMode();
    synth.renderNextBlock (buffer, midi, 0, numSamples);

    juce::dsp::AudioBlock<float> block (buffer);
    juce::dsp::ProcessContextReplacing<float> ctx (block);

    // Chorus
    const float cMix = chorusMix->load();
    if (cMix > 0.001f)
    {
        chorus.setRate (chorusRate->load());
        chorus.setMix (cMix * 0.5f);
        chorus.process (ctx);
    }

    // Stereo-Delay mit Kreuz-Feedback (Ping-Pong-Charakter)
    const float dMix = delayMix->load();
    delaySamples.setTargetValue (delayTime->load() * 0.001f * (float) getSampleRate());
    if (dMix > 0.001f)
    {
        const float fb = delayFb->load();
        float* l = buffer.getWritePointer (0);
        float* r = numChannels > 1 ? buffer.getWritePointer (1) : nullptr;
        for (int s = 0; s < numSamples; ++s)
        {
            const float d  = delaySamples.getNextValue();
            const float inL = l[s];
            const float inR = r != nullptr ? r[s] : inL;
            const float dl = delay.popSample (0, d);
            const float dr = numChannels > 1 ? delay.popSample (1, d) : dl;
            delay.pushSample (0, inL + dr * fb);
            if (numChannels > 1)
                delay.pushSample (1, inR + dl * fb);
            l[s] = inL + dl * dMix;
            if (r != nullptr)
                r[s] = inR + dr * dMix;
        }
    }
    else
    {
        delaySamples.skip (numSamples);
    }

    // Reverb
    const float rMix = revMix->load();
    if (rMix > 0.001f)
    {
        juce::Reverb::Parameters rp;
        rp.roomSize   = revSize->load();
        rp.damping    = revDamp->load();
        rp.wetLevel   = rMix * 0.5f;
        rp.dryLevel   = 1.0f - rMix * 0.5f;
        rp.width      = 1.0f;
        rp.freezeMode = 0.0f;
        reverb.setParameters (rp);
        reverb.process (ctx);
    }

    buffer.applyGain (juce::Decibels::decibelsToGain (master->load()));
}

int NebulaAudioProcessor::getNumPrograms()
{
    return (int) getPresets().size();
}

const juce::String NebulaAudioProcessor::getProgramName (int index)
{
    const auto& p = getPresets();
    if (! juce::isPositiveAndBelow (index, (int) p.size()))
        return {};
    const auto& pr = p[(size_t) index];
    return juce::String (pr.category).isEmpty() ? juce::String (pr.name)
                                                : juce::String (pr.category) + ": " + pr.name;
}

juce::String NebulaAudioProcessor::getPresetCategory (int index) const
{
    const auto& p = getPresets();
    return juce::isPositiveAndBelow (index, (int) p.size()) ? juce::String (p[(size_t) index].category) : juce::String();
}

juce::String NebulaAudioProcessor::getPresetShortName (int index) const
{
    const auto& p = getPresets();
    return juce::isPositiveAndBelow (index, (int) p.size()) ? juce::String (p[(size_t) index].name) : juce::String();
}

void NebulaAudioProcessor::setCurrentProgram (int index)
{
    if (! juce::isPositiveAndBelow (index, getNumPrograms()) || index == currentProgram)
        return;
    currentProgram = index;
    applyPreset (index);
}

void NebulaAudioProcessor::applyPreset (int index)
{
    for (auto* param : getParameters())
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (param))
            rp->setValueNotifyingHost (rp->getDefaultValue());

    for (const auto& v : getPresets()[(size_t) index].values)
        if (auto* rp = apvts.getParameter (v.id))
            rp->setValueNotifyingHost (rp->convertTo0to1 (v.value));
}

void NebulaAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("program", currentProgram, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, destData);
}

void NebulaAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
        {
            auto tree = juce::ValueTree::fromXml (*xml);
            currentProgram = tree.getProperty ("program", 0);
            apvts.replaceState (tree);
        }
}

juce::AudioProcessorEditor* NebulaAudioProcessor::createEditor()
{
    return new NebulaEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new NebulaAudioProcessor();
}
